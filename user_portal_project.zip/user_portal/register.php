<?php
include "db.php";
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email     = $_POST['email'];
    $password  = $_POST['password'];
    $confirm   = $_POST['confirm'];

    if ($password != $confirm) {
        $msg = "Oops! Passwords didn't match.";
    } else {
        $check = $conn->query("SELECT * FROM users WHERE full_name='$full_name'");
        if ($check->num_rows > 0) {
            $msg = "This name is already registered.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $conn->query("INSERT INTO users (full_name, email, password, created_at) VALUES ('$full_name', '$email', '$hashed', NOW())");
            header("Location: signin.php");
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Create Account</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>Register</h2>
<form method="POST">
    <input type="text" name="full_name" required placeholder="Full Name"><br>
    <input type="email" name="email" required placeholder="Email Address"><br>
    <input type="password" name="password" required placeholder="New Password"><br>
    <input type="password" name="confirm" required placeholder="Confirm Password"><br>
    <button type="submit">Create Account</button>
    <p class="msg"><?php echo $msg; ?></p>
</form>
<a href="signin.php">Go to Login</a>
</body></html>