<?php
include "db.php";
session_start();
$msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE full_name='$full_name'");
    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['full_name'] = $full_name;
            header("Location: dashboard.php");
        } else {
            $msg = "Wrong password. Try again.";
        }
    } else {
        $msg = "No account found with that name.";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Sign In</title><link rel="stylesheet" href="style.css"></head>
<body>
<h2>Sign In</h2>
<form method="POST">
    <input type="text" name="full_name" required placeholder="Your Full Name"><br>
    <input type="password" name="password" required placeholder="Your Password"><br>
    <button type="submit">Sign In</button>
    <p class="msg"><?php echo $msg; ?></p>
</form>
<a href="register.php">Create a New Account</a>
</body></html>