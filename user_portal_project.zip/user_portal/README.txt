USER PORTAL LOGIN SYSTEM - SETUP GUIDE

1. Copy the folder 'user_portal' to: C:/xampp/htdocs/

2. Start Apache and MySQL from XAMPP.

3. Go to: http://localhost/phpmyadmin/

4. Create database: user_auth

5. Run the following SQL inside user_auth database:
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) UNIQUE,
    email VARCHAR(100),
    password VARCHAR(255),
    created_at DATETIME
);

6. Visit: http://localhost/user_portal/register.php to test the system.

Done!
