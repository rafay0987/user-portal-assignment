<?php
session_start();
if (!isset($_SESSION['full_name'])) {
    header("Location: signin.php");
}
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard</title></head>
<body>
    <h2>Hello, <?php echo $_SESSION['full_name']; ?>!</h2>
    <p>You're now logged in.</p>
    <a href="signout.php">Logout</a>
</body></html>